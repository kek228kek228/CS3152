package edu.cornell.gdiac.Game.golf;

import com.badlogic.gdx.math.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.physics.box2d.*;

import edu.cornell.gdiac.util.*;
import edu.cornell.gdiac.Game.*;
import edu.cornell.gdiac.Game.obstacle.*;

public class BallModel extends WheelObstacle{

    // Default physics values
    /** The density of this ball */
    private static float DEFAULT_DENSITY  =  1.0f;
    /** The friction of this ball */
    private static float DEFAULT_FRICTION = 0.1f;
    /** The restitution of this ball */
    private static float DEFAULT_RESTITUTION = 0.4f;
    /** The thrust factor to convert player input into thrust */
    private static float DEFAULT_THRUST = 4.0f;
    /** The max thrust that can be applied to the ball in one hit*/
    private static float MAX_THRUST = 1000;

    /** The force to apply to this rocket */
    private Vector2 force;

    /** Cache object for transforming the force according the object angle */
    public Affine2 affineCache = new Affine2();
    /** The direction the ball is facing. Should have length 1*/
    private final Vector2 DirectionVectorCache = new Vector2(0,1);

    /**
     * Returns the force applied to this ball.
     *
     * This method returns a reference to the force vector, allowing it to be modified.
     * Remember to modify the input values by the thrust amount before assigning
     * the value to force.
     *
     * @return the force applied to this ball.
     */
    public Vector2 getForce() {
        return force;
    }

    /**
     * Returns the x-component of the force applied to this ball.
     *
     * Remember to modify the input values by the thrust amount before assigning
     * the value to force.
     *
     * @return the x-component of the force applied to this ball.
     */
    public float getFX() {
        return force.x;
    }

    /**
     * Sets the x-component of the force applied to this ball.
     *
     * Remember to modify the input values by the thrust amount before assigning
     * the value to force.
     *
     * @param value the x-component of the force applied to this ball.
     */
    public void setFX(float value) {
        force.x = value;
    }

    /**
     * Returns the y-component of the force applied to this ball.
     *
     * Remember to modify the input values by the thrust amount before assigning
     * the value to force.
     *
     * @return the y-component of the force applied to this ball.
     */
    public float getFY() {
        return force.y;
    }

    /**
     * Sets the x-component of the force applied to this ball.
     *
     * Remember to modify the input values by the thrust amount before assigning
     * the value to force.
     *
     * @param value the x-component of the force applied to this ball.
     */
    public void setFY(float value) {
        force.y = value;
    }

    /**
     * Change the {@code facingDirection} of the ball by setting angular speed
     * @param omega how much angular force to apply.
     */
    public void setAngularF(float omega){
        body.setAngularVelocity(omega*2);
    }

    public Vector2 getFacingDirection(){
        return DirectionVectorCache.cpy().rotate(body.getAngle());
    }

    public void setThrust(float thrust){
         DEFAULT_THRUST = thrust;
    }

    public float getThrust(){
        return DEFAULT_THRUST;
    }

    public void setMaxThrust(float thrust){
        MAX_THRUST = thrust;
    }

    public float getMaxThrust(){
        return MAX_THRUST;
    }
    /**
     * Creates a new ball at the origin.
     *
     * The size is expressed in physics units NOT pixels.  In order for
     * drawing to work properly, you MUST set the drawScale. The drawScale
     * converts the physics units to pixels.
     *
     * @param width		The object width in physics units
     * @param height	The object width in physics units
     */
    public BallModel(float radius) {
        this(0,0,radius);
    }

    /**
     * Creates a new ball at the given position.
     *
     * The size is expressed in physics units NOT pixels.  In order for
     * drawing to work properly, you MUST set the drawScale. The drawScale
     * converts the physics units to pixels.
     *
     * @param x  		Initial x position of the box center
     * @param y  		Initial y position of the box center
     * @param radius	The object radius
     */
    public BallModel(float x, float y, float radius) {
        super(x,y,radius);
        force = new Vector2();
        setDensity(DEFAULT_DENSITY);
        setFriction(DEFAULT_FRICTION);
        setRestitution(DEFAULT_RESTITUTION);
        setBullet(true);
        setName("ball");
    }

    /**
     * Creates the physics Body(s) for this object, adding them to the world.
     *
     * This method overrides the base method to keep your ship from spinning.
     *
     * @param world Box2D world to store body
     *
     * @return true if object allocation succeeded
     */
    public boolean activatePhysics(World world) {
        // Get the box body from our parent class
        if (!super.activatePhysics(world)) {
            return false;
        }

        return true;
    }


    /**
     * Applies the force to the ball
     *
     * This method should be called after the force attribute is set.
     */
    public void applyForce() {
        if (!isActive()) {
            return;
        }
        // Orient the force with rotation.
        affineCache.setToRotationRad(getAngle());
        affineCache.applyTo(force);

        // Apply force to the rocket BODY, not the rocket
        body.applyForce(force,body.getPosition(),true);
        body.setFixedRotation(true);
    }

    /**
     * Draws the physics object.
     *
     * @param canvas Drawing context
     */
    public void draw(GameCanvas canvas) {
        super.draw(canvas);
    }

}
