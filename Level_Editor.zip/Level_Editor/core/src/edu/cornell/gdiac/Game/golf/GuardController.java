package edu.cornell.gdiac.Game.golf;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.RayCastCallback;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.utils.Array;
import edu.cornell.gdiac.Game.obstacle.Obstacle;
import edu.cornell.gdiac.util.PooledList;

import java.util.*;

/**
 * A Game AI for guards.
 */
public class GuardController {
    /**
     * Square of how close a guard has to be to his target
     * position in order to consider it reached
     * TODO 25 is an arbitrary value
     * TODO not sure if we should do this because if they are not touching then
     * TODO CollisionController will not announce the winning condition
     **/
    private static final int POSITION_PADDING = 5;

    /**
     * How much movement can a guard perform in one turn,
     * including turning and move
     * TODO 10f is an arbitrary value.
     */
    private static final float TOTAL_MOVEMENT = 10f;
    /**
     * The position of the target
     */
    private Vector2 targetPos;
    /**
     * The last seen position of the ball
     */
    private Vector2 lastSeenBallPos;
    /**
     * The last seen position of the an alarm
     * If there are multiple, this is the closest
     */
    private AlarmModel lastActivatedAlarm;
    /**
     * Current state
     */
    private FSMState state;
    /**
     * A reference to the guard this controls
     */
    private GuardModel guard;
    /**
     * A reference to all the objects in the world
     */
    private PooledList<Obstacle> objects;
    /**
     * Waypoints for guards to move.
     * Stationary guards have only one element in this.
     */
    private Vector2[] waypoints;
    /**
     * The currently chasing waypoint's index in {@code waypoints}
     */
    private int currentWaypoint = 0;
    /**
     * A reference to the ball for ease of access
     */
    private BallModel ball;
    /**
     * a rayCastable implementer for body detection
     */
    private RayCastable rayCastable;
    /**
     * a reference to the game world for raycasting
     */
    private World world;

    private boolean rcbuff = false;
    private float timetonext=-0.01f;
    private Vector2 movedir;

    /**
     * Constructor for a GuardController
     *
     * @param guard       The guard the controller is controlling
     * @param rayCastable the RayCastable implementer for ball detection
     * @param objects     All Game objects
     * @param ball        The ball
     * @param waypoints   The points that make up the pathway
     */
    public GuardController(GuardModel guard, RayCastable rayCastable,
                           PooledList<Obstacle> objects, BallModel ball,
                           Vector2[] waypoints) {

        //Make sure the guard has a location
        assert waypoints.length != 0;

        this.rayCastable = rayCastable;
        this.ball = ball;
        this.guard = guard;
        this.objects = objects;
        this.waypoints = waypoints;
        targetPos = waypoints[0];
        state = FSMState.SPAWN;
        guard.setDirection(targetPos.cpy().sub(guard.getPosition()).nor());

    }

    /**
     * Update the guard movement accordingly
     *
     * @param dt Number of seconds since last animation frame
     */
    public void update(float dt) {
        changeStateIfApplicable();
        updateTargetLocation();
        if (timetonext < 0){
            movedir = getDirToTarget();
            timetonext += 0.1f;
        }
        moveToTarget(movedir,dt);
        timetonext -= dt;
//        guard.updateVelocity(dt);
        //TODO
    }

    /**
     * Change the state of the guard and guarantee an updated {@code targetPos}

     * <p>
     * A Finite State Machine (FSM) is just a collection of rules that,
     * given a current state, and given certain observations about the
     * environment, chooses a new state.
     */
    private void changeStateIfApplicable() {
        switch (state) {
            case SPAWN:
                state = FSMState.PATROL;
                break;

            case RETURN:
                if (targetReached()) state = FSMState.PATROL;
                if (detectedAlarm()) state = FSMState.ALARM_CHASING;
                break;

            case PATROL:
                if (detectedAlarm()) state = FSMState.ALARM_CHASING;
                break;

            case BALL_CHASING:
                if (targetReached()) {
                    //reached ball's last seen location but game has not ended
                    chaseFailedTransition();
                    state = FSMState.RETURN;
                }
                break;

            case ALARM_CHASING:
                if (targetReached()) {
                    alarmReachedTransition();
                    state = FSMState.RETURN;
                }
                //In case there is another alarm
                if (detectedAlarm()) state = FSMState.ALARM_CHASING;
                break;
        }
        //Whenever the ball is in sight, chase it.
        if (detectedBall()) {
            state = FSMState.BALL_CHASING;
        }
    }

    /**
     * Alarm is reached, and this is a placeholder for
     * potentially guard turn off the alarm animation
     */
    private void alarmReachedTransition() {
        //TODO turn off alarm if still activated
    }

    /**
     * Chasing is done up to {@code lastSeenBallPos} but no ball in sight.
     * This is a placeholder for potential animation
     * of guard being confused of where the ball headed
     */
    private void chaseFailedTransition() {
        //TODO potentially set a flag to affect drawing
    }

    /**
     * Update {@code targetPos} according to a  {@code state}
     * {@code state} state must be up-to-date, so is
     * {@code lastSeenBallPos} and {@code lastActivatedAlarm}
     */
    private void updateTargetLocation() {
        switch (state) {
            case SPAWN:
            case RETURN:
            case PATROL:
                //All three cases means going to the current waypoint
                targetPos = waypoints[currentWaypoint];

                //Update the waypoint when necessary
                if (targetReached()) {
                    currentWaypoint = (++currentWaypoint) % waypoints.length;
                    targetPos = waypoints[currentWaypoint];
                }
                break;

            case BALL_CHASING:
                targetPos = lastSeenBallPos;
                break;

            case ALARM_CHASING:
                targetPos = lastActivatedAlarm.getPosition();
                break;
        }
    }


    /**
     * Use path finding and move accordingly to the target
     */
    private Vector2 getDirToTarget() {
        //TODO by YX. PATH-FINDING!

        //Check if direct path exists
        if (rayCastable.checkGuardMovement(guard.getPosition(),targetPos)){

            return targetPos.cpy().sub(guard.getPosition());
        };
        int curx = Math.round(guard.getPosition().x);
        int cury = Math.round(guard.getPosition().y);
        int tarx = Math.round(targetPos.x);
        int tary = Math.round(targetPos.y);
        HashMap<int[],Vector2> dirmap = new HashMap<>();
        Array<int[]> visited = new Array<>();
        Queue<int[]> searchq = new ArrayDeque<int[]>();
        Array<int[]> nbors = new Array<>();
        int[] cur = new int[]{curx,cury};
        searchq.add(cur);
        dirmap.put(cur,new Vector2());
        while (searchq.size() != 0){
            int[] newpos = searchq.poll();
            //If we found the target
            if (newpos[0] == tarx && newpos[1] == tary){
                return dirmap.get(newpos);
            }
            //If we already visited the target
            boolean alrvisited = false;
            for (int[] c : visited){
                if (newpos[0] == c[0] && newpos[1] == c[1]){
                    alrvisited = true;
                }
            }
            if (alrvisited){
                continue;
            }
            visited.add(newpos);
            //Get neighbors
            nbors.clear();
            nbors.add(new int[]{newpos[0]-1,newpos[1]});
            nbors.add(new int[]{newpos[0]+1,newpos[1]});
            nbors.add(new int[]{newpos[0],newpos[1]-1});
            nbors.add(new int[]{newpos[0],newpos[1]+1});
            for (int i = 0;i<4;i++){
                int[] temp = nbors.get(i);
                //Check it is possible to get there
                if (!rayCastable.checkGuardMovement(new Vector2(newpos[0],newpos[1]),new Vector2(temp[0],temp[1]))){
                    continue;
                };
                //Check if already in queue to visit
                boolean flag = false;
                for (int[] loc:searchq){
                    if (loc[0] == temp[0] && loc[1] == temp[1]){
                        flag = true;
                    }
                }
                if (flag){
                    continue;
                }
                //End check
                searchq.add(temp);
                if (dirmap.get(newpos).isZero(0.01f)){
                    switch (i){
                        case 0:
                            dirmap.put(temp,new Vector2(-1,0));
                            break;
                        case 1:
                            dirmap.put(temp,new Vector2(1,0));
                            break;
                        case 2:
                            dirmap.put(temp,new Vector2(0,-1));
                            break;
                        case 3:
                            dirmap.put(temp,new Vector2(0,1));
                            break;
                    }
                } else {
                    dirmap.put(temp, dirmap.get(newpos));
                }
            }
        }
        System.out.println("ERROR PATH NOT FOUND");
        return new Vector2(0,0);
        //Note: when setting movement, be aware of {@code TOTAL_MOVEMENT}
        //Which is how much you can turn AND move forward in the same turn.
    }

    /**
     * handles the actual movement of the guard
     * @param direction direction we want the guard to move in.
     */
    private void moveToTarget(Vector2 direction,float dt){
        guard.move(direction, dt);
    }

    /**
     * Use path finding and move accordingly to the target
     */
    private boolean targetReached() {
        return (distanceWithGuard(targetPos) < POSITION_PADDING);
    }

    /**
     * Determines if the ball is detected
     * If so, update {@code lastSeenBallPos}
     *
     * @return whether the ball can be detected
     */
    public boolean detectedBall() {
        //Directions of the ray
        Vector2 guardPos = guard.getPosition();
        Vector2 dir = guard.getDirection().cpy().rotate(-(guard.fov / 2));

        //Iterate all ray
        for (int i = 0; i < guard.numrays; i++) {
            dir.rotate(guard.fov / guard.numrays);
            Vector2 p2 = guardPos.cpy().add(dir.cpy().scl(guard.dist));

            if (rayCastable.nearest(guardPos, p2) == ball.getBody()) {
                //Ray passes through the ball!
                lastSeenBallPos = ball.getPosition();
                return true;
            }
        }
        return false;
    }

    /**
     * Determines if an alarm is ringing and
     * update {@code lastActivatedAlarm} if so
     *
     * @return whether there is an alarm that is activated
     */
    private boolean detectedAlarm() {
        boolean tempAlarmed = false;
        float closestAlarmDistance = Float.MAX_VALUE;
        AlarmModel alarm;

        //Find all alarms that are in the objects
        //TODO potential performance upgrade: save all alarms at the first time
        for (Obstacle ob : objects) {
            if (ob instanceof AlarmModel) {
                alarm = (AlarmModel) ob;

                //Update {@code lastActivatedAlarm}
                if (alarm.isActivated()) {
                    // Make sure the closest activated alarm will be chosen
                    float distance = distanceWithGuard(alarm.getPosition());
                    if (distance < closestAlarmDistance) {
                        lastActivatedAlarm = alarm;
                        tempAlarmed = true;
                    }
                }
            }
        }
        return tempAlarmed;
    }

    /**
     * Check distance between the given one and the guard, squared for optimization
     *
     * @param loc location of the destination
     * @return the calculated distance squared
     */
    private float distanceWithGuard(Vector2 loc) {
        return guard.getPosition().cpy().sub(loc).len2();
    }


    /**
     * Enumeration to encode the finite state machine.
     */
    private enum FSMState {
        /**
         * The guard just spawned
         */
        SPAWN,
        /**
         * The guard is patrolling around along its defined path
         */
        PATROL,
        /**
         * The guard holds a location of the ball and is chasing it
         */
        BALL_CHASING,
        /**
         * The guard reaching to an alarm
         */
        ALARM_CHASING,
        /**
         * The guard returning to its original position
         */
        RETURN,

    }
}
