package edu.cornell.gdiac.Game.golf;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.World;
import edu.cornell.gdiac.Game.obstacle.Obstacle;

/**
 * Avoid cyclic dependence between {@see GolfController} and
 * {@see GuardController}
 */
public interface RayCastable {
    /**
     * For an ray, return its nearest body it touches
     * @param center The emitting center
     * @param aPoint a point
     * @return the nearest body
     */
    Body nearest(Vector2 center,Vector2 aPoint);

    /**
     * Check whether the guard can move from p1 to p2
     * @param p1 starting point
     * @param p2 ending point
     * @return
     */
    Boolean checkGuardMovement(Vector2 p1, Vector2 p2);
}
