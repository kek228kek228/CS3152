package edu.cornell.gdiac.Game.golf;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.math.Affine2;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.RayCastCallback;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.utils.Array;
import edu.cornell.gdiac.Game.GameCanvas;
import edu.cornell.gdiac.Game.obstacle.BoxObstacle;
import edu.cornell.gdiac.Game.obstacle.WheelObstacle;

public class GuardModel extends WheelObstacle {

    // Default physics values
    private static final float DEFAULT_DENSITY = 1.0f;
    private static final float DEFAULT_FRICTION = 0.1f;
    private static final float DEFAULT_RESTITUTION = 0.4f;
    private static final float SPEED = 3.0f;

    //TODO documentation
    private Vector2 direction;
    private Array<Float> cues;
    private Array<Vector2> directions;
    private Float curtime;
    private int stage;

    public final int numrays = 270;
    public final float fov = 30;
    public final float dist = 8;

    /**
     * Creates a new ball at the given position.
     * <p>
     * The size is expressed in physics units NOT pixels.  In order for
     * drawing to work properly, you MUST set the drawScale. The drawScale
     * converts the physics units to pixels.
     *
     * @param x      Initial x position of the box center
     * @param y      Initial y position of the box center
     * @param radius The object radius in physics units
     */
    public GuardModel(float x, float y, float radius) {
        super(x, y, radius);
        setDensity(DEFAULT_DENSITY);
        setDensity(DEFAULT_DENSITY);
        setFriction(DEFAULT_FRICTION);
        setRestitution(DEFAULT_RESTITUTION);
    }

    public Vector2 getDirection() {
        return direction;
    }

    public void setDirection(Vector2 direction) {
        this.direction = direction.nor();
    }

    public void setCues(Array<Float> cues) {
        this.cues = cues;
    }

    public void setDirections(Array<Vector2> directions) {
        this.directions = directions;
    }


    /**
     * Creates the physics Body(s) for this object, adding them to the world.
     *
     * This method overrides the base method to keep your ship from spinning.
     *
     * @param world Box2D world to store body
     *
     * @return true if object allocation succeeded
     */
    public boolean activatePhysics(World world) {
        // Get the box body from our parent class
        if (!super.activatePhysics(world)) {
            return false;
        }

        return true;
    }

    /**
     * Draws the physics object.
     *
     * @param canvas Drawing context
     */
    public void draw(GameCanvas canvas) {
        super.draw(canvas);
    }

    //TODO documentation
    public void updateVelocity(float dt) {
        if (cues == null) {
            return;
        }
        if (curtime == null) {
            stage = 0;
            curtime = cues.get(0);
        }
        curtime -= dt;
        if (curtime < 0) {
            stage = (stage+1) % cues.size;
            if (stage == cues.size){
                stage = 0;
            }
            curtime = cues.get(stage) - curtime;
        }
        setLinearVelocity(directions.get(stage).cpy());
        setDirection(directions.get(stage).cpy());
    }

    /**
     * Moves the guard towards
     * @param direction
     * @param dt
     */
    public void move(Vector2 direction, float dt){
        setDirection(direction.cpy().nor());
        setLinearVelocity(direction.cpy().nor().scl(SPEED));
    }

}
