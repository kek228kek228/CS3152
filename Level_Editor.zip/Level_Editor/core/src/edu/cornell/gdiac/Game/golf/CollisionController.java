package edu.cornell.gdiac.Game.golf;

/**
 * {@link CollisionController} provides functions for contact listeners
 * Might be static? (Not sure)
 */
public class CollisionController {

    /**
     * If a guard collides with an alarm the alarm will be deactivated
     * @param alarm
     * @param guard
     */
    public void handleCollision(AlarmModel alarm, GuardModel guard){
        //TODO should turn that alarm off
        alarm.deactivate();
    }

    /**
     * If the ball collides with an alarm the alarm will be activated
     * @param alarm
     * @param ball
     */
    public void handleCollision(AlarmModel alarm, BallModel ball){
        //TODO should turn that alarm on
        alarm.activate();
    }

    /**
     * If the ball collides with a guard from the front, returns true
     * Otherwise, returns false
     * @param guard
     * @param ball
     * @return
     */
    public boolean handleCollision(GuardModel guard, BallModel ball){
        // By returning true if it is the GolfController that calls this function it will know that GAMEOVER
        //TODO should somehow let GolfController know that GAMEOVER
        if (ball.getFacingDirection().x <= guard.getDirection().x) {
            return true;
        }
        return false;
    }

    public void handleCollision(GuardModel guard1, GuardModel guard2){
        //TODO when level design is bad then guards bump to each other
        // then somehow set one to cooldown while let the other move
    }

}
