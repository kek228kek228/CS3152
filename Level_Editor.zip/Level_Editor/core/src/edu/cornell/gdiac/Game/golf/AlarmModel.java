package edu.cornell.gdiac.Game.golf;

import edu.cornell.gdiac.Game.obstacle.BoxObstacle;

/**
 * AlarmModel represents an alarm which can be activated by
 * balls passing on it.
 */
public class AlarmModel extends BoxObstacle {

    /**
     * Whether the the alarm is activated
     */
    boolean isActivated;

    /**
     * Whether the alarm is activated
     *
     * @return if the alarm is activated
     */
    public boolean isActivated() {
        return isActivated;
    }

    /**
     * activate the alarm regardless of its current state
     */
    public void activate() {
        isActivated = true;
    }

    /**
     * deactivate the alarm regardless of its current state
     */
    public void deactivate() {
        isActivated = false;
    }


    /**
     * Creates a new alarm object.
     * <p>
     * The size is expressed in physics units NOT pixels.  In order for
     * drawing to work properly, you MUST set the drawScale. The drawScale
     * converts the physics units to pixels.
     *
     * @param x      Initial x position of the alarm center
     * @param y      Initial y position of the alarm center
     * @param width  The object width in physics units
     * @param height The object width in physics units
     */
    public AlarmModel(float x, float y, float width, float height) {
        super(x, y, width, height);
        setName("alarm");
        isActivated = false;
        //TODO if anything else
    }
}
