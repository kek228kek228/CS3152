/*
 * GolfController.java
 *
 */
package edu.cornell.gdiac.Game.golf;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Affine2;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.physics.box2d.joints.FrictionJointDef;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Slider;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import edu.cornell.gdiac.Game.InputController;
import edu.cornell.gdiac.Game.WorldController;
import edu.cornell.gdiac.Game.obstacle.BoxObstacle;
import edu.cornell.gdiac.Game.obstacle.Obstacle;
import edu.cornell.gdiac.Game.obstacle.PolygonObstacle;

import java.security.Guard;

/**
 * {@link GolfController} is a controller for an individual level.
 * And it deals with drawing directly.
 * <p>
 * It keeps references to all created {@link Obstacle}s and
 * make them available for {@link GuardController} to use (pathfinding specifically)
 */
public class GolfController extends WorldController implements ContactListener, RayCastable {




    /**
     * Reference to the rocket texture
     */
    private static final String BALL_TEXTURE = "golf/ball.png";
    private static final String GUARD_TEXTURE = "golf/guard.png";
    private static final String BEAM_TEXTURE = "golf/beam.png";
    private static final String ARROW_TEXTURE = "golf/arrow.png";
    /**
     * Density of the wall objects
     */
    private static final float BASIC_DENSITY = 0.0f;
    /**
     * Friction of all objects
     */
    private static final float BASIC_FRICTION = 0.1f;
    /**
     * Collision restitution for all objects
     */
    private static final float BASIC_RESTITUTION = 0.1f;
    // Other game objects
    private static final float[] WALL1 = {0.0f, 18.0f, 32.0f, 18.0f,
            32.0f, 17.0f, 1.0f, 17.0f,
            1.0f, 0.0f, 0f, 0f};
    private static final float[] WALL2 = {0.0f, 1.0f, 31.0f, 1.0f,
            31.0f, 18.0f, 32.0f, 18.0f,
            32.0f, 0.0f, 0f, 0f};
    private static final float[] WALL3 = {21f, 1f, 21f, 1.7f, 21.1f, 1.7f, 21.1f, 1f};
    private static final float[] WALL4 = {21f, 3.3f, 21f, 4f, 21.1f, 4f, 21.1f, 3.3f};
    private static final float[] WALL5 = {21f, 7f, 21f, 13f, 21.1f, 13f, 21.1f, 7f};
    private static final float[] WALL6 = {24f, 4f, 24f, 4.6f, 24.1f, 4.6f, 24.1f, 4f};
    private static final float[] WALL7 = {24f, 6.3f, 24f, 7f, 24.1f, 7f, 24.1f, 6.3f};
    private static final float[] WALL8 = {21f, 3.9f, 21f, 4f, 24.1f, 4f, 24.1f, 3.9f};
    private static final float[] WALL9 = {21f, 7f, 21f, 7.1f, 24.1f, 7.1f, 24.1f, 7f};
//    private static final float[] WALL4 = {14f, 6f, 14f, 8f, 16f, 8f, 16f, 6f};
    private static final float[] WALL12 = {1f, 1f, 1f, 4f, 16f, 4f, 16f, 1f};
    private static final float[] WALL13 = {1f, 7f, 1f, 18f, 16f, 18f, 16f, 7f};
    private static final float[][] WALL_ARRAY = new float[][]{WALL1, WALL2,WALL3,WALL4,WALL5,WALL6,WALL7,WALL8,WALL9,WALL12,WALL13};
    private static final int numrays = 270;
    private static final float fov = 30;
    private static final float dist = 8;
    //TODO remove above hard-coded value wisely XD
    /**
     * The initial ball position
     */
    private static Vector2 BALL_POS = new Vector2(28, 4);


    // Physics constants for initialization
    /**
     * Guard position
     */
    private static Vector2 GUARD_POS = new Vector2(15, 9);
    /**
     * The goal door position
     */
    private static Vector2 GOAL_POS = new Vector2(2.5f, 5.5f);
    /**
     * Guards Avatars to Rotate
     */
    private final boolean GUARDS_ROTATION = false;
    /**
     * object buffers
     */
    PolygonObstacle obj;
    GuardModel guard;
    GuardController gc;
    /**
     * pauseFlag is an flag for pause screen (a method)
     * -1 means screen update not be not paused
     * 0 means it is paused by user
     * 1 means it is paused by satisfying winning condition
     * 2 means it is paused by satisfying lose condition
     */
    private int pauseFlag = -1;
    /**
     * Texture assets for the rocket
     */
    private TextureRegion ballTexture;
    private TextureRegion guardTexture;
    private TextureRegion beamTexture;
    private TextureRegion arrowTexture;
    // Physics objects for the game
    /**
     * Track asset loading from all instances and subclasses
     */
    private AssetState golfAssetState = AssetState.EMPTY;
    /**
     * Whether or not debug mode is active
     */
    private boolean debug;
    /**
     * Reference to the goal (for collision detection)
     */
    private BoxObstacle goalDoor;
    /**
     * Reference to the ball
     */
    private BallModel ball;

    /**
     * Number of guards
     */
    private int numGuards = 2;
    /**
     * Reference to the guards
     */
    private Array<GuardModel> guards = new Array<>();
    /**
     * Reference to the guard controllers
     */
    private Array<GuardController> gcontrollers = new Array<>();
    /**
     * Reference to the ground
     */
    private Body groundBody;
    /**
     * Reference to whether or not the arrow should be drawn
     */
    private boolean drawArrow;
    private Vector2 arrowLength;
    private float mouseX;
    private float mouseY;
    private float initX;
    private float initY;
    private boolean wasNotPressed = true;
    private Vector2 collisionPoint;
    private boolean ballspotted;
    private boolean tempspotted;
    private float closest = 1f;
    private boolean rcbuff = false;

    /**
     * Creates and initialize a new instance of the rocket lander game
     * <p>
     * The game has default gravity and other settings
     */
    public GolfController() {
        setDebug(false);
        setComplete(false);
        setFailure(false);
        world.setContactListener(this);
        world.setGravity(new Vector2(0, 0));
    }

    /**
     * Preloads the assets for this controller.
     * <p>
     * To make the game modes more for-loop friendly, we opted for nonstatic loaders
     * this time.  However, we still want the assets themselves to be static.  So
     * we have an AssetState that determines the current loading state.  If the
     * assets are already loaded, this method will do nothing.
     *
     * @param manager Reference to global asset manager.
     */
    public void preLoadContent(AssetManager manager) {
        if (golfAssetState != AssetState.EMPTY) {
            return;
        }

        golfAssetState = AssetState.LOADING;

        // Ball textures
        manager.load(BALL_TEXTURE, Texture.class);
        assets.add(BALL_TEXTURE);
        manager.load(GUARD_TEXTURE, Texture.class);
        assets.add(GUARD_TEXTURE);
        manager.load(BEAM_TEXTURE, Texture.class);
        assets.add(BEAM_TEXTURE);
        manager.load(ARROW_TEXTURE, Texture.class);
        assets.add(ARROW_TEXTURE);

        super.preLoadContent(manager);
    }

    /**
     * Loads the assets for this controller.
     * <p>
     * To make the game modes more for-loop friendly, we opted for nonstatic loaders
     * this time.  However, we still want the assets themselves to be static.  So
     * we have an AssetState that determines the current loading state.  If the
     * assets are already loaded, this method will do nothing.
     *
     * @param manager Reference to global asset manager.
     */
    public void loadContent(AssetManager manager) {
        if (golfAssetState != AssetState.LOADING) {
            return;
        }

        ballTexture = createTexture(manager, BALL_TEXTURE, false);
        guardTexture = createTexture(manager, GUARD_TEXTURE, false);
        beamTexture = createTexture(manager, BEAM_TEXTURE, false);
        arrowTexture = createTexture(manager, ARROW_TEXTURE, false);

        super.loadContent(manager);
        golfAssetState = AssetState.COMPLETE;
    }

    /**
     * Resets the status of the game so that we can play again.
     * <p>
     * This method disposes of the world and creates a new one.
     */
    public void reset() {
        Vector2 gravity = new Vector2(world.getGravity() );

        for(Obstacle obj : objects) {
            obj.deactivatePhysics(world);
        }
        objects.clear();
        addQueue.clear();
        world.dispose();

        world = new World(gravity,false);
        world.setContactListener(this);
        setComplete(false);
        setFailure(false);
        populateLevel();
    }

    /**
     * Setter for pauseFlag
     *
     * @param pauseFlag new value (-1~2)
     */
    public void setPauseFlag(int pauseFlag) {
        this.pauseFlag = pauseFlag;
    }

    /**
     * Lays out the game geography
     */
    public void populateLevel() {
        // Draw goal
//        float dwidth = goalTile.getRegionWidth() / scale.x;
//        float dheight = goalTile.getRegionHeight() / scale.y;
//        System.out.println(dwidth);
//        System.out.println(dheight);
//        goalDoor = new BoxObstacle(GOAL_POS.x, GOAL_POS.y, dwidth, dheight);
//        goalDoor.setBodyType(BodyDef.BodyType.StaticBody);
//        goalDoor.setDensity(0.0f);
//        goalDoor.setFriction(0.0f);
//        goalDoor.setRestitution(0.0f);
//        goalDoor.setSensor(true);
//        goalDoor.setDrawScale(scale);
//        goalDoor.setTexture(goalTile);
//        addObject(goalDoor);
//        // Draw ball
//        float dradius = ballTexture.getRegionWidth() / scale.x;
//        ball = new BallModel(BALL_POS.x, BALL_POS.y, 0.5f*dradius);
//        ball.setDrawScale(scale);
//        ball.setTexture(ballTexture);
//        ball.setName("ball");
//        addObject(ball);

        // Create guards
//        guards = new Array<GuardModel>(numGuards);
//        gcontrollers = new Array<GuardController>(numGuards);
        //need to find a good way to store information related to guards (especially after parsing json)
        //also need to decide on how to store guards

        //guard1 directions
//        Vector2[] g1wpts = new Vector2[2];
//        g1wpts[1] = new Vector2(GUARD_POS.x-0,GUARD_POS.y-3.5f);
//        g1wpts[0] = new Vector2(GUARD_POS.x-10,GUARD_POS.y-3.5f);
//        addGuard(new Vector2(GUARD_POS.x -9, GUARD_POS.y - 3.5f), g1wpts);
//        //guard2 directions and cues
//        Vector2[] g2wpts = new Vector2[2];
//        g2wpts[1] = new Vector2(GUARD_POS.x+10,GUARD_POS.y+6);
//        g2wpts[0] = new Vector2(GUARD_POS.x+10,GUARD_POS.y-6);
//        addGuard(new Vector2(GUARD_POS.x +10, GUARD_POS.y - 0), g2wpts);

        // Create walls
        // for the future, when we have level editor, we can iterate through the data file and add all walls this way
        // if we use for each then naming the walls is hard, but names might not be important
//        for (int i = 0; i < WALL_ARRAY.length; i++) {
//            addWall(WALL_ARRAY[i]);
//        }


        // Create ground for friction
//        BodyDef groundBodyDef = new BodyDef();
//        groundBody = world.createBody(groundBodyDef);
//        for (Obstacle o : objects) {
//            //Prevent guards form being affected
//            //End guards
//            //Prevent infinite self-rotating
//            o.setAngularDamping(10);
//
//            //Prevent guards from rotating at all
//            if (!GUARDS_ROTATION) {
//                if (o instanceof GuardModel)
//                    o.setFixedRotation(true);
//            }
//
//            //Create friction on everything with an imaginary friction joint
//            FrictionJointDef frictionJointDef = new FrictionJointDef();
//            frictionJointDef.bodyA = groundBody;
//            frictionJointDef.bodyB = o.getBody();
//            frictionJointDef.maxForce = 10;
//            world.createJoint(frictionJointDef);
//        }


        //create sliders
//        Skin skin = new Skin(Gdx.files.internal("golf/uiskin.json"));
//
//        final Slider slider1 = new Slider(0, 10, 0.1f, false, skin);
//        slider1.setPosition(0, 0);
//        slider1.setValue(4f);
//        slider1.addListener(new ChangeListener() {
//            @Override
//            public void changed(ChangeEvent event, Actor actor) {
//                ball.setThrust(slider1.getValue());
//            }
//        });
//        stage.addActor(slider1);
//
//
//        final Slider slider2 = new Slider(0, 10, 0.01f, false, skin);
//        slider2.setPosition(300, 0);
//        slider2.setValue(1f);
//        slider2.addListener(new ChangeListener() {
//            @Override
//            public void changed(ChangeEvent event, Actor actor) {
//                ball.setDensity(slider2.getValue());
//            }
//        });
//        stage.addActor(slider2);
//
//
//        final Slider slider3 = new Slider(0, 1, 0.01f, false, skin);
//        slider3.setPosition(600, 0);
//        slider3.setValue(0.4f);
//        slider3.addListener(new ChangeListener() {
//            @Override
//            public void changed(ChangeEvent event, Actor actor) {
//                ball.setRestitution(slider3.getValue());
//            }
//        });
//        stage.addActor(slider3);
//
//
//        final Slider slider4 = new Slider(0, 1, 0.01f, false, skin);
//        slider4.setPosition(850, 0);
//        slider4.setValue(0.1f);
//        slider4.addListener(new ChangeListener() {
//            @Override
//            public void changed(ChangeEvent event, Actor actor) {
//                ball.setFriction(slider4.getValue());
//            }
//        });
//        stage.addActor(slider4);
//
//        final Slider slider5 = new Slider(0, 1000, 25, false, skin);
//        slider5.setPosition(0, 200);
//        slider5.setValue(1000);
//        slider5.addListener(new ChangeListener() {
//            @Override
//            public void changed(ChangeEvent event, Actor actor) {
//                ball.setMaxThrust(slider5.getValue());
//            }
//        });
//        stage.addActor(slider5);
//
//
//        InputMultiplexer inputMultiplexer = new InputMultiplexer();
//        inputMultiplexer.addProcessor(InputController.getInstance().mouse);
//        inputMultiplexer.addProcessor(stage);
//        Gdx.input.setInputProcessor(inputMultiplexer);
    }


    /**
     * The core gameplay loop of this level world.
     * <p>
     * This method contains the specific update code for this mini-game. It does
     * not handle collisions, as those are managed by the parent class WorldController.
     * This method is called after input is read, but before collisions are resolved.
     * The very last thing that it should do is apply forces to the appropriate objects.
     *
     * @param dt Number of seconds since last animation frame
     */
    public void update(float dt) {
        world.step(WORLD_STEP,WORLD_VELOC,WORLD_POSIT);
        stage.act(dt);
        //#region Check if win or lose
        //TODO if win or lose then call pause screen with different flag value
        // eg 1 could be won 2 could be lose but regardless just a option screen shows up (pause method to be made)
        //#endregion

        //#region Get User Input
//        InputController input = InputController.getInstance();
//        if (input.getKeyPressed() && wasNotPressed) {
//            wasNotPressed = false;
//            drawArrow = true;
//            arrowLength = input.getDragVector();
//            initX = input.getMouseX();
//            initY = input.getMouseY();
//        }
//        mouseX = input.getMouseX();
//        mouseY = input.getMouseY();
//        //TODO check above GameSpec code and make sure it works
//        //#endregion
//
//        //#region Respond to User Input
//        //TODO switch "No user input," "Clicking and Dragging," and "just released"
//        // for example we have GameSpec code below
//        if (input.didDrag()) {
//            if (ball.getLinearVelocity().len() == 0) {
//
//                float clampedX  = Math.max(-ball.getMaxThrust(),Math.min(ball.getMaxThrust(),input.getDragVector().x));
//                float clampedY  = Math.max(-ball.getMaxThrust(),Math.min(ball.getMaxThrust(),input.getDragVector().y));
//                System.out.println("here");
//                System.out.println(clampedX);
//                ball.setFX(clampedX * ball.getThrust());
//                ball.setFY(-clampedY * ball.getThrust());
//                ball.applyForce();
//            }
//            wasNotPressed = true;
//            drawArrow = false;
//            input.setDragFalse();
//            arrowLength = input.getDragVector();
//        }
//        //#endregion
//
//        //#region Update Guards
//        for (GuardController gc : gcontrollers){
//            gc.update(dt);
//        }
//
//        //TODO Change above GameSpec code and call all guards' AI's update, which should update its velocities.
//        //#endregion
//
//        //#region Reset
//        if (input.didReset()) {
//            reset();
//        }
        //#endregion

        //#region Draw(?)
        //TODO Call draw on every objects (Not sure because we have a draw method here)
        //#endregion
    }

    /// CONTACT LISTENER METHODS

    /**
     * Callback method for the start of a collision
     * <p>
     * This method is called when we first get a collision between two objects.  We use
     * this method to test if it is the "right" kind of collision.  In particular, we
     * use it to test if we made it to the win door.
     *
     * @param contact The two bodies that collided
     */
    public void beginContact(Contact contact) {
        Body body1 = contact.getFixtureA().getBody();
        Body body2 = contact.getFixtureB().getBody();

        if ((body1.getUserData() == ball && body2.getUserData() == goalDoor) ||
                (body1.getUserData() == goalDoor && body2.getUserData() == ball)) {
            setComplete(true);
        }

        //TODO use functions from {@link CollisionController} and call them accordingly
    }

    /**
     * Callback method for the start of a collision
     * <p>
     * This method is called when two objects cease to touch.  We do not use it.
     */
    public void endContact(Contact contact) {
        Body body1 = contact.getFixtureA().getBody();
        Body body2 = contact.getFixtureB().getBody();

        if ((body1.getUserData() == ball && body2.getUserData() == goalDoor) ||
                (body1.getUserData() == goalDoor && body2.getUserData() == ball)) {
            setComplete(false);
        }

        //TODO use functions from {@link CollisionController} and call them accordingly
    }

    /**
     * Unused ContactListener method
     */
    public void postSolve(Contact contact, ContactImpulse impulse) {
    }

    /**
     * Handles any modifications necessary before collision resolution
     * <p>
     * This method is called just before Box2D resolves a collision.  We use this method
     * to implement sound on contact, using the algorithms outlined similar to those in
     * Ian Parberry's "Introduction to Game Physics with Box2D".
     * <p>
     * However, we cannot use the proper algorithms, because LibGDX does not implement
     * b2GetPointStates from Box2D.  The danger with our approximation is that we may
     * get a collision over multiple frames (instead of detecting the first frame), and
     * so play a sound repeatedly.  Fortunately, the cooldown hack in SoundController
     * prevents this from happening.
     *
     * @param contact     The two bodies that collided
     * @param oldManifold The collision manifold before contact
     */

    public void preSolve(Contact contact, Manifold oldManifold) {

    }

    /**
     * Change velocity of the ball.
     *
     * @param coeff A value of (0,1] indicating hitting strength
     */
    public void setBallMovement(float coeff) {
        ball.setFX(ball.getFacingDirection().x * coeff);
        ball.setFY(ball.getFacingDirection().y * coeff);
        ball.applyForce();
    }

    public void draw(float delta) {
        canvas.clear();

//        canvas.begin();
//        for (Obstacle obj : objects) {
//            obj.draw(canvas);
//        }

//
//        String message = "Thrust: " + ball.getThrust();
//        String message2 = "Density: " + ball.getDensity();
//        String message3 = "Restitution: " + ball.getRestitution();
//        String message4 = "Friction: " + ball.getFriction();
//        String message5 = "Max Power: " + ball.getMaxThrust();
//        canvas.drawText(message, displayFont, 0, 30);
//        canvas.drawText(message2, displayFont, 300, 30);
//        canvas.drawText(message3, displayFont, 600, 30);
//        canvas.drawText(message4, displayFont, 850, 30);
//        canvas.drawText(message5, displayFont, 0, 230);
//        canvas.end();

        stage.draw();
        //RAYCASTING
        //TODO make raycasting to become invisible and make detection in GuardController Class
//        ballspotted = false;
//        tempspotted = false;
//        for (GuardModel guard : guards) {
//            //Raycast testing
//            Vector2 p1 = guard.getPosition();
//            p1.x += 0.01;
//            p1.y += 0.02;
//            Vector2 dir = guard.getDirection().cpy().rotate(-(fov / 2));
//            Vector2 p2;
//            RayCastCallback callback = new RayCastCallback() {
//                @Override
//                public float reportRayFixture(Fixture fixture, Vector2 point, Vector2 normal, float fraction) {
//
//                    if (fixture.getBody().getUserData() == ball && fraction < closest) {
//                        closest = fraction;
//                        tempspotted = true;
//                    }
//                    if (fixture.getBody().getUserData() != groundBody && fraction < closest) {
//                        closest = fraction;
//                        tempspotted = false;
//                    }
//                    collisionPoint = point;
//                    return fraction;
//                }
//            };
//            for (int i = 0; i < numrays; i++) {
//                dir.rotate(fov / numrays);
//                p2 = p1.cpy().add(dir.cpy().scl(dist));
//                collisionPoint = null;
//                closest = 2;
//                world.rayCast(callback, p1, p2);
//                if (tempspotted) {
//                    ballspotted = true;
//                }
//                if (collisionPoint != null) {
//                    canvas.drawLine(p1.x * scale.x, p1.y * scale.y, collisionPoint.x * scale.x, collisionPoint.y * scale.y, Color.RED);
//                } else {
//                    canvas.drawLine(p1.x * scale.x, p1.y * scale.y, p2.x * scale.x, p2.y * scale.y, Color.BLACK);
//                }
//            }
//        }
//        if (ballspotted) {
//            setFailure(true);
//        } else {
//            setFailure(false);
//        }
//        //END RAYCASTING
//
//        if (drawArrow) {
//            canvas.begin();
//            double ydiff = Math.max(Math.min((mouseY - initY),ball.getMaxThrust()),-ball.getMaxThrust());
//            double xdiff = Math.max(Math.min((mouseX - initX),ball.getMaxThrust()),-ball.getMaxThrust());
//            System.out.println(xdiff);
//            Affine2 oTran = new Affine2();
//            oTran.setToTranslation(new Vector2(ball.getX() * ball.getDrawScale().x, ball.getY() * ball.getDrawScale().y));
//            oTran.rotateRad(-(float) (Math.atan2(ydiff, xdiff) + Math.PI));
//            oTran.scale((float)(Math.min( Math.max((Math.sqrt(((ydiff * ydiff) + (xdiff * xdiff)) * 0.05) / (arrowTexture.getRegionWidth() / 2)),0.2f),1.0f)), 0.5f);
//            canvas.draw(arrowTexture,
//                    new Color(Math.min((float) (Math.sqrt((ydiff * ydiff) + (xdiff * xdiff)) * 0.5 / arrowTexture.getRegionWidth()), 1),
//                            Math.max((float) (1 - Math.sqrt((ydiff * ydiff) + (xdiff * xdiff)) * 0.5 / arrowTexture.getRegionWidth()), 0), 0, 1),
//                    0, arrowTexture.getRegionHeight() / 2, oTran);
//            canvas.end();
//        }
//        // Final message
//        if (isComplete() && !isFailure()) {
//            displayFont.setColor(Color.BLUE);
//            canvas.begin(); // DO NOT SCALE
//            canvas.drawTextCentered("You win :)", displayFont, 0.0f);
//            canvas.end();
//            displayFont.setColor(Color.WHITE);
//        } else if (isFailure()) {
//            displayFont.setColor(Color.RED);
//            canvas.begin(); // DO NOT SCALE
//            canvas.drawTextCentered("You got spotted :(", displayFont, 0.0f);
//            canvas.end();
//            displayFont.setColor(Color.WHITE);
//        }
    }


    /**
     * Creates a wall using the given points at the origin with the given name.
     * <p>
     * The points are relative to the origin of the wall.
     *
     * @param points The wall vertices
     */
    private void addWall(float[] points) {
        obj = new PolygonObstacle(points);
        obj.setBodyType(BodyDef.BodyType.StaticBody);
        obj.setDensity(BASIC_DENSITY);
        obj.setFriction(BASIC_FRICTION);
        obj.setRestitution(BASIC_RESTITUTION);
        obj.setDrawScale(scale);
        obj.setTexture(wallTile);
        obj.setName("wall");
        addObject(obj);
    }

    /**
     * Creates a guard with the given position and behaviours
     * <p>
     * The size of the directions list should be the same size as the cues list.
     * The guard will move according to each direction's index for the amount of time equal to
     * the time specified in the cues array.
     * <p>
     * For example, if the directions[0] contains a vector pointing right and directions[1] contains a vector
     * pointing left while cues[0] = 1f and cues[1] = 2f, the guard will move right for 1 second then left for
     * 2 seconds, and then repeat.
     *
     * @param position   the starting position of the guard
     * @param waypoints the sequence of waypoints of the guard
     */
    private void addGuard(Vector2 position, Vector2[] waypoints) {
        guard = new GuardModel(position.x, position.y,
                0.5f*guardTexture.getRegionWidth() / scale.x);
        guard.setDrawScale(scale);
        guard.setTexture(guardTexture);
        guard.setName("guard");
        gc = new GuardController(guard,this,objects,ball,waypoints);
//        gc = new GuardController(guard,world,objects,ball,waypoints);
        guards.add(guard);
        gcontrollers.add(gc);
        addObject(guard);
    }
    private Stage stage = new Stage();




    /**
     * For an ray, return its nearest body it touches
     * @param center The emitting center of a ray
     * @param aPoint a point on the ray
     * @return the nearest body the ray passes through
     */
    @Override
    public Body nearest(Vector2 center,Vector2 aPoint) {
        final Body[] tempSpotted = new Body[1];
        closest = 2;
        RayCastCallback callback = new RayCastCallback() {
            @Override
            public float reportRayFixture(Fixture fixture, Vector2 point, Vector2 normal, float fraction) {
                if (fixture.getBody().getUserData() == ball && fraction < closest) {
                    closest = fraction;
                    tempSpotted[0] = fixture.getBody();
                }
                if (fixture.getBody().getUserData() != ball && fraction < closest) {
                    closest = fraction;
                    tempSpotted[0] = fixture.getBody();
                }
                return fraction;
            }
        };
        world.rayCast(callback,center,aPoint);
        return tempSpotted[0];
    }

    @Override
    public Boolean checkGuardMovement(Vector2 p1, Vector2 p2){
        //callback function for raycasting
        RayCastCallback callback = new RayCastCallback() {
            @Override
            public float reportRayFixture(Fixture fixture, Vector2 point, Vector2 normal, float fraction) {
                String fixturename = ((Obstacle)fixture.getBody().getUserData()).getName();
                if (fixturename == "guard" || fixturename == "ball"){
                    return 1;
                }
                rcbuff = false;
                return 0;
            }
        };
        rcbuff = true;
        world.rayCast(callback,p1,p2);
//        Check all 4 side of guards
        float radius = 0.5f*guardTexture.getRegionWidth() / scale.x;
        world.rayCast(callback,p1.cpy().sub(radius,0),p2.cpy().sub(radius,0));
        world.rayCast(callback,p1.cpy().add(radius,0),p2.cpy().add(radius,0));
        world.rayCast(callback,p1.cpy().sub(0, radius),p2.cpy().sub(0, radius));
        world.rayCast(callback,p1.cpy().add(0, radius),p2.cpy().add(0, radius));
        return rcbuff;
    }
}