package edu.cornell.gdiac.Game.golf;

/**
 * {@link Level} represents a level
 */
public class Level {
}
