package edu.cornell.gdiac.Game.golf;

import com.badlogic.gdx.math.Affine2;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.World;
import edu.cornell.gdiac.Game.GameCanvas;
import edu.cornell.gdiac.Game.obstacle.BoxObstacle;

/**
 * {@link BoxModel} is a representation of a movable box on the map.
 */
public class BoxModel extends BoxObstacle {

    // Default physics values
    /** The density of this box */
    private static final float DEFAULT_DENSITY  =  1.0f;
    /** The friction of this box */
    private static final float DEFAULT_FRICTION = 0.1f;
    /** The restitution of this box */
    private static final float DEFAULT_RESTITUTION = 0.4f;

    /** The force to apply to this box */
    private Vector2 force;
    /** Cache object for transforming the force according the object angle */
    public Affine2 affineCache = new Affine2();

    /**
     * Returns the force applied to this ball.
     *
     * This method returns a reference to the force vector, allowing it to be modified.
     * Remember to modify the input values by the thrust amount before assigning
     * the value to force.
     *
     * @return the force applied to this ball.
     */
    public Vector2 getForce() {
        return force;
    }

    /**
     * Returns the x-component of the force applied to this ball.
     *
     * Remember to modify the input values by the thrust amount before assigning
     * the value to force.
     *
     * @return the x-component of the force applied to this ball.
     */
    public float getFX() {
        return force.x;
    }

    /**
     * Sets the x-component of the force applied to this ball.
     *
     * Remember to modify the input values by the thrust amount before assigning
     * the value to force.
     *
     * @param value the x-component of the force applied to this ball.
     */
    public void setFX(float value) {
        force.x = value;
    }

    /**
     * Returns the y-component of the force applied to this ball.
     *
     * Remember to modify the input values by the thrust amount before assigning
     * the value to force.
     *
     * @return the y-component of the force applied to this ball.
     */
    public float getFY() {
        return force.y;
    }

    /**
     * Sets the x-component of the force applied to this ball.
     *
     * Remember to modify the input values by the thrust amount before assigning
     * the value to force.
     *
     * @param value the x-component of the force applied to this ball.
     */
    public void setFY(float value) {
        force.y = value;
    }

    /**
     * Creates a new box at the given position.
     *
     * The size is expressed in physics units NOT pixels.  In order for
     * drawing to work properly, you MUST set the drawScale. The drawScale
     * converts the physics units to pixels.
     *
     * @param x  		Initial x position of the box2d box center
     * @param y  		Initial y position of the box2d box center
     * @param width		The object width in physics units
     * @param height	The object width in physics units
     */
    public BoxModel(float x, float y, float width, float height) {
        super(x,y,width,height);
        force = new Vector2();
        setDensity(DEFAULT_DENSITY);
        setDensity(DEFAULT_DENSITY);
        setFriction(DEFAULT_FRICTION);
        setRestitution(DEFAULT_RESTITUTION);
        setName("box");
        //TODO
    }

    /**
     * Creates the physics Body(s) for this object, adding them to the world.
     *
     * This method overrides the base method to keep your ship from spinning.
     *
     * @param world Box2D world to store body
     *
     * @return true if object allocation succeeded
     */
    public boolean activatePhysics(World world) {
        // Get the box body from our parent class
        if (!super.activatePhysics(world)) {
            return false;
        }

        return true;
    }


    /**
     * Applies the force to the ball
     *
     * This method should be called after the force attribute is set.
     */
    public void applyForce() {
        if (!isActive()) {
            return;
        }

        // Orient the force with rotation.
        affineCache.setToRotationRad(getAngle());
        affineCache.applyTo(force);

        // Apply force to the rocket BODY, not the rocket
        body.applyForce(force,body.getPosition(),true);
        body.setFixedRotation(true);
    }

    /**
     * Draws the physics object.
     *
     * @param canvas Drawing context
     */
    public void draw(GameCanvas canvas) {
        super.draw(canvas);
    }

}
