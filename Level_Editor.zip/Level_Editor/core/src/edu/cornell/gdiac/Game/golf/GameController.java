package edu.cornell.gdiac.Game.golf;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Affine2;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.physics.box2d.joints.FrictionJointDef;
import com.badlogic.gdx.utils.Array;
import edu.cornell.gdiac.Game.GameCanvas;
import edu.cornell.gdiac.Game.InputController;
import edu.cornell.gdiac.Game.WorldController;
import edu.cornell.gdiac.Game.obstacle.BoxObstacle;
import edu.cornell.gdiac.Game.obstacle.Obstacle;
import edu.cornell.gdiac.Game.obstacle.PolygonObstacle;
import edu.cornell.gdiac.util.ScreenListener;

/**
 * {@link GameController} is an controller direct under
 * {@link edu.cornell.gdiac.Game.GDXRoot} and is parallel to
 * {@link edu.cornell.gdiac.Game.LoadingMode}
 * and {@link edu.cornell.gdiac.Game.MenuScreen} and switch when necessary.
 * <p>
 * It creates instances of {@link GolfController} for different {@link Level}s
 * and control drawing over there.
 */
public class GameController extends WorldController {

    /**
     * Enumeration to encode the finite state machine.
     */
    private enum GameState {
        /**
         * Menu screen
         */
        MENU,
        /**
         * Currently playing a level
         */
        PLAY,
        /**
         * Currently paused
         */
        PAUSED,
    }
    /**
     * A flag value for GDX root to swap
     */
    private GameState state;
    /**
     * The current level, 0-indexed
     */
    private int level = 0;
    /**
     * List of all the levels (golf controllers)
     */
    private GolfController[] levels;

    private AssetManager manager;
    private GameCanvas canvas;

    /**
     * Creates and initialize a new instance of the rocket lander game
     * <p>
     * The game has default gravity and other settings
     */
    public GameController(GameCanvas canvas, AssetManager manager) {
        this.manager = manager;
        this.canvas = canvas;
        state = GameState.PLAY;
        levels = new GolfController[1];
        levels[0] = new GolfController();

        levels[0].loadContent(manager);
        levels[0].setCanvas(canvas);
    }

    /**
     * Preloads the assets for this controller.
     * <p>
     * To make the game modes more for-loop friendly, we opted for nonstatic loaders
     * this time.  However, we still want the assets themselves to be static.  So
     * we have an AssetState that determines the current loading state.  If the
     * assets are already loaded, this method will do nothing.
     *
     * @param manager Reference to global asset manager.
     */
    public void preLoadContent(AssetManager manager) {
        for (GolfController gc: levels) {
            gc.preLoadContent(manager);
        }
        super.preLoadContent(manager);
    }

    /**
     * Loads the assets for this controller.
     * <p>
     * To make the game modes more for-loop friendly, we opted for nonstatic loaders
     * this time.  However, we still want the assets themselves to be static.  So
     * we have an AssetState that determines the current loading state.  If the
     * assets are already loaded, this method will do nothing.
     *
     * @param manager Reference to global asset manager.
     */
    public void loadContent(AssetManager manager) {
        for (GolfController gc: levels) {
            gc.loadContent(manager);
        }
        super.loadContent(manager);
    }

    /**
     * Resets the status of the game so that we can play again.
     * <p>
     * This method disposes of the world and creates a new one.
     */
    public void reset() {
        levels[0].reset();
    }

    /**
     * The core gameplay loop of this level world.
     * <p>
     * This method contains the specific update code for this mini-game. It does
     * not handle collisions, as those are managed by the parent class WorldController.
     * This method is called after input is read, but before collisions are resolved.
     * The very last thing that it should do is apply forces to the appropriate objects.
     *
     * @param dt Number of seconds since last animation frame
     */
    public void update(float dt) {
        levels[0].update(dt);
    }

    public void draw(float delta) {
        levels[0].draw(delta);
    }

}
