package edu.cornell.gdiac.Game;

/**
 * {@link JsonLoader} handles I/O and parse Json to some TBD intermediate formats that can
 * be later used to parse to {@link edu.cornell.gdiac.Game.golf.Level}s
 */
public class JsonLoader {

}
