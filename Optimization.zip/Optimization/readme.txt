CS3152 Lab4

Kevin Klaben

What is Newton's second law of motion? 
Do not just write F = ma; explain the intuition behind it.
The mass of an object and when multiplied with the acceleration in a direction of that object can give us the force vector of that object.

What is momentum? Impulse?
Momentum in general is the amount of motion of a body and is equal to the mass x velocity of an object. Impulse is the integral of force applied to an object over time. The impulse is the change in momentum as a result of the force over time.

What is a perfectly elastic collision? 
Give a real-life example of a (nearly) perfectly elastic collision.
A collision in which no kinetic energy is lost in the collision. A near perfectly elastic collision is pool balls as very little kinetic energy is lost in the collision between balls.

What is a perfectly inelastic collision?
Give a real-life example of a (nearly) perfectly inelastic collision.
A perfectly inelastic collision occurs when all kinetic energy is lost in collision. An example of a near perfectly inelastic collision would be the collision of two lumps of clay together which will stick together.

What is the coefficient of restitution? What range of values can it take?
It is in the range of 0-1 and denotes the ratio of final velocity to initial velocity when two objects collide.

What is angular velocity? Angular acceleration?
Angular velocity is how fast an object revolves around a point. It is equal to the velocity times the radius form the point of rotation. Angular acceleration is the rate of change of angular velocity. It is calculated by angular velocity over time.

What is the moment of inertia? Angular momentum?
The moment of inertia is the ratio of angular momentum to angular velocity about an axis. The angular momentum is the quantity of rotation of an object.

What is torque?
Torque is the twisting/turning force that leads to rotation. It is equal to the force times the radius and the SIN(angle) at which that force acts on the object.

What is the relationship between torque, moment of inertia, and angular acceleration?
The torque is essentially the rotational force that is working to make an object rotate, the momentum inertia is essentially the rational mass that is taking work to start rotating and the angular acceleration is the amount to which the torque is overcoming the moment of inter of an object and speeding up the rotation of an object.



In Box2d, what is the difference between a Shape and a Body?
A body is an invisible object which holds many properties (mass, velocity, angular velocity, etc.), the shape is attached to a body and gives it a physical presence on the screen as to how the object should look and what size it should be.

Between a Shape and a Body, which do you go to to change a physical property?
To apply a force?
To change a physical property you would make a change to the shape, whereas to a apply a force you would modify the body.

When would you want a Body to contain multiple Shapes?
To create irregular shapes which can be attached and react to one another despite not even having to be attached.

In Box2d, what is a World? What are some of its important properties?
A the world is a collection of bodies, fixtures, and constraints that interact. The key properties that come with a world include a physics solver that will update and resolve physics of everything in the world.

What is the advantage of sleeping an object with a Body?
When would you want to do this?
Sleeping a body is used for efficiency, when a body comes to rest and sleep is enabled, it is excluded form the simulation until another object interacts with it. This allows the world to skip over updating bodies when they are sleeping as long as no other body interacts with them. We would want to do this anytime were are doing something that is computationally intense as this will make the code run more efficiently.

In Box2d, what is the difference between a static body and a dynamic body?
How do you specify which type a body is?
A static body is one which is unaffected by forces and collisions and will maintain its current location while a dynamic body will be influenced by forces and collisions. You can  specify static vs. dynamic bodies during the definition of the body using the type attribute.

In Box2d, what is a Bullet and when do you want an object to be one?
A bullet body is one that does not allow overlap during collisions. This will be more intensive in terms of calculations but it is useful when bodies are moving very fast and it might be possible for them to skip completely over another body if they are not treated as bullet bodies.

In LibGDX, what can you do with a ContactListener inside of a World?
How does this help with sensors?
The ContactListener checks to see if there are objects in the world which are hitting each other. A shape can be made into a sensor which allows the ContactListener to keep track of 
This shapes actions and collisions.

In LibGDX, what are the steps that you must take to add a Shape to a Body?
A shape can be added to a body using the create fixture function.

If you simply set the spinner to be static like other platforms, it will not move upon contact with the player and thus it will not act as a spinner as intended.

